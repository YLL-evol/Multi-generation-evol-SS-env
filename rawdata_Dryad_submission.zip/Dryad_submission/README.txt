# Data to perform all analyses carried out in "Sexual selection shapes the evolution of physiological and life history traits"
Martin D. Garlovsky*, Department of Animal and Plant Sciences, University of Sheffield, UK
Luke Holman*, School of Applied Sciences, Edinburgh Napier University, UK
Andrew L. Brooks, Department of Animal and Plant Sciences, University of Sheffield, UK
Rhonda R. Snook, Department of Zoology, Stockholm University, Sweden

*These authors contributed equally to this work

1.eclosion_wide.csv 
# Wide format data (converted to long format in R script)
- rows correspond to collection day
- columns correspond to vial identity in the format: replicate_seed.day_vial_sex
- cells reflect number of flies emerging on given day in each vial

1.wing_length.csv
# Wing vein 4 measurements output from ImageJ
$Treatment - Elevated polyandry (coded as P) or enforced monogamy (M)
$Rep - replicate R1 to R4 (recoded in R script to reflect selection line)
$Sex - Male (M) or Female (F)
$Seed - Day on which larvae were seeded to vial (A, B, or C)
$Slide - Slide ID (recycled)
$Individual - Fly ID (recycled)
$Side - Left (L) or Right (R) wing
$Area
$Mean
$Min
$Max
$Length - length of wing vein 4 in microns

2.DesRes.csv
# Survival data for desiccation resistance assay. 
# Survival times are calculated from "04/02/2017 12:00"
$Vial - vial ID (recycled across replicates)
$Treatment - Elevated polyandry (coded as P) or enforced monogamy (M)
$Replicate - replicate R1 to R4 (recoded in R script to reflect selection line)
$Sex - Male (m) or Female (f)
$Death_date
$Death_time - death times were recorded every 2 hours in 24 hour format, i.e. 22 = 22:00

2.StarvRes.csv
# Survival data for starvation resistance assay. 
# Survival times are calculated from "04/02/2017 10:00"
$Vial - vial ID (recycled across replicates)
$Treatment - Elevated polyandry (coded as P) or enforced monogamy (M)
$Replicate - replicate R1 to R4 (recoded in R script to reflect selection line)
$Sex - Male (m) or Female (f)
$Death_date
$Death_time - death times were recorded every 2 hours in 24 hour format, i.e. 22 = 22:00

3.metabolic_rates.csv
# Respirometry data collected for triads of flies
$?SELECTION - Elevated polyandry (coded as Poly) or enforced monogamy (Mono)
$SEX - Male (M) or Female (F)
$LINE - replicate M1 to M4 and P1 - P4
$SAMPLE - vial identity
$CYCLE - Cycle I, II, or III in which measurements were recorded
$VO2 - volume of oxygen consumed
$VCO2 - volumen of carbon dioxide produced
$RQ - respiratory quotient VCO2/VO2
$ACTIVITY - activity recorded with infrared light
$BODY_WEIGHT - dry weight in milligrams (repeated for the three measurements/cycles of each vial)

4.metabolite_data.csv
# Macro-metabolite data collected for triads of flies - see supplementary material for details
$sex - Male (m) or Female (f)
$treatment - Elevated polyandry (coded as P) or enforced monogamy (M)
$line - replicate 1 to 4 (recoded in R script to reflect selection line)
$time - developmental time point (only 2 is used)
$fwt_mg - fresh weight of each triad in milligrams
$dwt_mg - dry weight of each triad in milligrams
$Hex_frac - Lipid content determined by subtracting the dry weight after hexane extraction from the initial dry weight
$p_hex_frac - Hex_frac/dwt_mg
$Aq_frac - Soluble carbohydrates calculated as the dry weight after hexane extraction minus the dry weight after ethanol extraction
$p_Aq_frac - Aq_frac/dwt_mg
$Protein - Soluble protein determined using standards of bovine serum albumin at an absorbance of 562nm 
$Protein_ug_mg - Protein/dwt_mg
$Glycogen - determined by the addition of 0.5 units of hexokinase taking readings at 340nm
$Glycogen_ug_mg - Glycogen/dwt_mg
$Chitin - determined by subtracting the final dry weight from the initial dry weight
$Chitin_mg_mg - Chitin/dwt_mg



